//Carolina Rodriguez
//CSD 402 Module 1.3
//The program calculates the energy needed to heat water 
// from an initial temperature to a final temperature then calculates it in Joules.

//Resources used:
//W3Schools. (n.d.). Java user input (Scanner class). W3Schools. Retrieved January 18, 2026 from https://www.w3schools.com/java/java_user_input.asp
//OpenAI. (2024). ChatGPT (January 14 version) [Large language model]. https://chat.openai.com/


// Import the Scanner class for user input
import java.util.Scanner; 

// Gain class definition
public class rodriguez_mod1_3_csd402 { 
// Main names waterMass, initialTemp, finalTemp, Q

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in); //Create Scanner object for input

        // Prompt the user, (system.out.print string prints text without a new line)
        System.out.print("Enter the amount of water in kilograms: ");
        double waterMass = input.nextDouble(); //.nextDouble reads decimal input 

        System.out.print("Enter the initial temperature of the water (°C): ");
        double initialTemp = input.nextDouble();

        System.out.print("Enter the final temperature of the water (°C): ");
        double finalTemp = input.nextDouble();

        // Calculate energy Q = waterMass * (finalTemp - initialTemp) * 4184
        double Q = waterMass * (finalTemp - initialTemp) * 4184;

        // Result output using printf for formatted output
        System.out.printf("The energy required to heat %.2f kg of water from %.2f°C to %.2f°C is %.2f Joules.%n",
                          waterMass, initialTemp, finalTemp, Q);

        input.close();
    }
}
